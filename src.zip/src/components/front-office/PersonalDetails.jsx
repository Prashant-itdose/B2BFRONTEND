import React, { useEffect, useRef, useState } from "react";
import ReactSelect from "@app/components/formComponent/ReactSelect";
import Input from "@app/components/formComponent/Input";
import LabeledInput from "@app/components/formComponent/LabeledInput";
import { Tabfunctionality } from "../../utils/helpers";
import { useTranslation } from "react-i18next";
import UploadImage from "./UploadImage";
import Modal from "../modalComponent/Modal";
import DatePicker from "../../components/formComponent/DatePicker";
import CityModel from "../modalComponent/Utils/CityModel";
import DistrictModel from "../modalComponent/Utils/DistrictModel";
import StateModel from "../modalComponent/Utils/StateModel";
import IMGLOLO from "../../assets/image/logoAadmiMan.gif";
import {
  BindCityBystateByDistrict,
  BindDistrictByCountryByState,
  BindStateByCountry,
  ageValidation,
  filterByType,
  filterByTypes,
  inputBoxValidation,
  notify,
} from "../../utils/utils";
import {
  AGE_TYPE,
  BIND_TABLE_OLDPATIENTSEARCH,
  BIND_TABLE_OLDPATIENTSEARCH_REG,
  MOBILE_NUMBER_VALIDATION_REGX,
  PAYMENT_OBJECT,
} from "../../utils/constant";
import {
  cityInsert,
  districtInsert,
  storeState,
} from "../../store/reducers/common/storeStateDistrictCity";
import { useDispatch } from "react-redux";
import { useLocalStorage } from "../../utils/hooks/useLocalStorage";
import AttachDoumentModal from "../modalComponent/Utils/AttachDoumentModal";
import UploadImageModal from "../modalComponent/Utils/UploadImageModal";
import { Tooltip } from "primereact/tooltip";
import moment from "moment/moment";
import { findAgeByDOB } from "../../networkServices/directPatientReg";
import { CentreWiseCacheByCenterID } from "../../store/reducers/common/CommonExportFunction";
import TestPayment from "./TestPayment";
import TestAddingTable from "../UI/customTable/frontofficetables/TestAddingTable";
import PaymentGateway from "./PaymentGateway";
import { AutoComplete } from "primereact/autocomplete";
import { useFormik } from "formik";
import { GetDoctorlist, Oldpatientsearch } from "../../networkServices/opdserviceAPI";
import { Button } from "react-bootstrap";
import DoctoModal from "./DoctorModal";
import image from "../../assets/image/avatar.gif"
import { fetchPanels, fetchPanelswithid, getCentres, getCentresworkorder, getPaymentmode } from "../../utils/helperfunctions";
import EasyUI from "../EasyUI/EasyUI";


export default function PersonalDetails() {
  const { VITE_DATE_FORMAT } = import.meta.env;
  const dispatch = useDispatch();
  const [formData, setformData] = useState({
    PatientID: "",
    LedgertransactionID: "",
    LedgertransactionNo: "",
    Mobile: "",
    Title: "",
    PName: "",
    Gender: "",
    years: "",
    months: "",
    days: "",
    Doctor: "",
    Address: "",
    Email: "",
    Phone: "",
    DateOfBirth: "",
    DOB:'',
    Doctor_ID: "",
    DoctorName: "",
    Panel_ID: "",
    PanelName: "",
    Discount: 0,
    PanelID:'',
    CentreId:'',
    ReferenceCodeOpd:'',
    mobedit:false,
    years:'',
    days:'',
    months:'',
    IsVip:0,
    PaymentMode:'',
    profileImage:image
  });
  const [handleModelData, setHandleModelData] = useState({});
  const [t] = useTranslation();
  const [modalData, setModalData] = useState({});
  const [isuploadDocOpen, setIsuploadDocOpen] = useState(false);
  const [singlePatientData, setSinglePatientData] = useState({});
  const [visible, setVisible] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState([]);
  const [paymentControlModeState, setPaymentControlModeState] =
    useState(PAYMENT_OBJECT);
  const [renderComponent, setRenderComponent] = useState({
    name: "",
    component: null,
  });
  const [addDoc, setAdddoc] = useState(false);

  const [discounts, setDiscounts] = useState({
    discountApprovalList: [],
    discountReasonList: [],
    discamount:'',
    discperc:''
  });
  const titleOptions = [
    { label: "Mr", value: "Mr.", gender: "Male" },
    { label: "Mrs", value: "Mrs.", gender: "Female" },
    { label: "Miss", value: "Miss.", gender: "Female" },
    { label: "Master", value: "Master", gender: "Male" },
    { label: "Baby", value: "Baby.", gender: "Female" },
    { label: "B/O", value: "B/O.", gender: "UnKnown" },
    { label: "Dr", value: "Dr.", gender: "UnKnown" },
    { label: "Prof", value: "Prof.", gender: "UnKnown" },
    { label: "Madam", value: "Madam.", gender: "Female" },
    { label: "Sister", value: "Sister.", gender: "Female" },
    { label: "Mohd", value: "Mohd.", gender: "Male" },
    { label: "Mx", value: "Mx", gender: "Female" },
    { label: "Transgendr", value: "Transgendr", gender: "Trans" },
    { label: "Ms", value: "Ms.", gender: "Female" },
  ];
  const [getOldPatientData, setGetOldPatientData] = useState([]);
  const [Panels,setPanels]=useState([]);
  const [Centres,setCenters]=useState([])
  // const handleListSearch = (data, name, Promo) => {
  //     switch (name) {

  //       case "DoctorName":
  //         const doctorName = data.label.split(' # ')[0];
  // setFieldValue('DoctorName', doctorName);
  // setFieldValue('Doctor_ID', data?.value);
  //         setIndexMatch(0);
  //         setDoctorSuggestion([]);
  //         setDropFalse(false);
  //         break;
  //      setIndexMatch(0);
  //         setDoctorSuggestion([]);

  //         break;
  //       default:
  //         break;
  //     }
  //   };
  const genderOptions = [
    { label:"Male", value:"Male" },
    { label:"Female", value:"Female" },
    { label:"Trans", value:"Trans" },
  ];
  const [payloadData, setPayloadData] = useState({
    panelID: "",
    referalTypeID: "Self",
    referDoctorID: "",
    DepartmentID: "ALL",
    DoctorID: "",
  });
  const inputRef = useRef(null);
  const [testPaymentState, setTestPaymentState] = useState({
    type: "",
    category: "0",
    subCategory: "0",
    searchType: 1,
  });
  const [testAddingTableState, setTestAddingTable] = useState([]);
  // const localdata = useLocalStorage("userData", "get");

  // const [singlePatientData, setSinglePatientData] = useState({});
  // const [getOldPatientData, setGetOldPatientData] = useState([]);
  const [preview, setPreview] = useState(null);
  const [isuploadOpen, setIsuploadOpen] = useState(false);
  const [cameraStream, setCameraStream] = useState(null);
  const [doctorSuggestion, setDoctorSuggestion] = useState([]);
  const videoRef = useRef();
  const canvasRef = useRef();

  const userData = useLocalStorage("userData", "get");
  const handleChangeModel = (data) => {
    setModalData(data);
  };
  const THEAD = ["Code", "ItemName", "Rate", "Action"];
  
  

  // const handleStateInsertAPI = async (data) => {
  //   let insData = await dispatch(storeState(data));
  //   if (insData?.payload?.status) {
  //     setModalData({});
  //     setHandleModelData((val) => ({ ...val, isOpen: false }));
  //     dispatch(
  //       CentreWiseCacheByCenterID({
  //         centreID: localdata?.defaultCentre,
  //       })
  //     );
  //   }
  // };
  // const handleDistrictInsertAPI = async (data) => {
  //   let insData = await dispatch(districtInsert(data));
  //   if (insData?.payload?.status) {
  //     setModalData({});
  //     setHandleModelData((val) => ({ ...val, isOpen: false }));
  //     dispatch(
  //       CentreWiseCacheByCenterID({
  //         centreID: localdata?.defaultCentre,
  //       })
  //     );
  //   }
  // };

  // const handleCityInsertAPI = async (data) => {
  //   let insData = await dispatch(cityInsert(data));
  //   if (insData?.payload?.status) {
  //     setModalData({});
  //     setHandleModelData((val) => ({ ...val, isOpen: false }));
  //     dispatch(
  //       CentreWiseCacheByCenterID({
  //         centreID: localdata?.defaultCentre,
  //       })
  //     );
  //   }
  // };
  const handleReactSelect = (name, value) => {
    setFieldValue(name, value);
    if(name=="CentreId") {
      setTestAddingTable([]);
      setFieldValue('PanelID','')
    }
    if(name=='PanelID')
      {setFieldValue('ReferenceCodeOpd',value?.code)
        setFieldValue('PaymentMode',value?.paymentmode)
        setTestAddingTable([])
      }
  };

  const handleModel = (
    label,
    width,
    type,
    isOpen,
    Component,
    handleInsertAPI,
    extrabutton
  ) => {
    setHandleModelData({
      label: label,
      width: width,
      type: type,
      isOpen: isOpen,
      Component: Component,
      handleInsertAPI: handleInsertAPI,
      extrabutton: extrabutton ? extrabutton : <></>,
    });
  };
  const handleDoctorSelected = (ID) => {
    setPayloadData({ ...payloadData, DoctorID: ID });
  };

  // useEffect(() => {
  //   setHandleModelData((val) => ({ ...val, modalData: modalData }));
  // }, [modalData]);

  const setIsOpen = () => {
    setHandleModelData((val) => ({ ...val, isOpen: false }));
  };

  const closeCameraStream = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach((track) => track.stop());
      setCameraStream(null);
    }
  };
  const { handleChange, values, setValues, setFieldValue, handleSubmit } =
    useFormik({
      initialValues: formData,
      onSubmit: async (values, { resetForm }) => {
        // SearchBillPrintAPI();
      },
    });

  // Function to start camera
  // const startCamera = async () => {
  //   try {
  //     setPreview(null);
  //     const stream = await navigator.mediaDevices.getUserMedia({ video: true });
  //     setCameraStream(stream); // Store camera stream
  //     videoRef.current.srcObject = stream;
  //   } catch (err) {
  //     console.error("Error accessing camera:", err);
  //   }
  // };
  const handleListSearch = (data) => {
    const doctorName = data.label.split(" # ")[0];
    setFieldValue("DoctorName", doctorName);
    setFieldValue("Doctor_ID", data.value);
    setDoctorSuggestion([]);
  };
  const getDoctorlist = async (query) => {
    let form = new FormData();
    form.append("ID", localStorage?.getItem("employeeId"));
    form.append("SessionCentreID", 1);
    form.append("SessionPanelID", 1);
    form.append("DoctorName", query);

    try {
      const dataResponse = await GetDoctorlist(form);
      setDoctorSuggestion(dataResponse.data.data);
    } catch (error) {
      console.error(error);
    }
  };
  const searchDoctors = (event) => {
    getDoctorlist(event.query);
  };

  const startCamera = async () => {
    try {
      setCameraStream(null);

      console.log("Checking for getUserMedia support...");
      const hasGetUserMedia = !!(
        navigator.mediaDevices && navigator.mediaDevices.getUserMedia
      );
      console.log("getUserMedia support:", hasGetUserMedia);

      if (!hasGetUserMedia) {
        throw new Error("getUserMedia is not supported in this browser");
      }

      console.log("Requesting camera access...");
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      console.log("Camera access granted");
      setCameraStream(stream); // Store camera stream
      videoRef.current.srcObject = stream;
    } catch (err) {
      console.error("Error accessing camera:", err);
    }
  };

  const takePhoto = () => {
    const context = canvasRef.current.getContext("2d");
    context.drawImage(videoRef.current, 0, 0, 200, 150);

    const canvas = canvasRef.current;
    const base64String = canvas.toDataURL("image/png");
    setPreview(base64String);
  };

  const handleImageChange = (e) => {
    e.preventDefault();

    let reader = new FileReader();
    let file = e.target.files[0];
    closeCameraStream();
    reader.onloadend = () => {
      // setImage(file);
      setPreview(reader.result);
    };

    if (file) {
      reader.readAsDataURL(file);
    }
  };

  const handleImageUpload = () => {
    // Upload logic here (e.g., send `image` state to server)
    if (image) {
      // `image` is a File object; convert it to base64 format if needed
      let reader = new FileReader();
      reader.readAsDataURL(image);
      reader.onloadend = () => {
        let base64data = reader.result;
        console.log(base64data); // Base64 format of the image
        // Perform your upload logic (e.g., send `base64data` to server)
      };
    }
  };
  const handlePaymentGateWay = (details) => {
    
    setPaymentMethod([]);
    setPaymentControlModeState(setData);
  };
  const handleClickEasyUI = (value) => {
    handleSinglePatientData(value); 
  };

  const handleSinglePatientData = async (patientDetails) => {
     console.log(patientDetails)
     const calculateAgeYears = (dob) => {
      if (!dob) return 0;
      const birthDate = new Date(dob);
      const today = new Date();
      let age = today.getFullYear() - birthDate.getFullYear();
      const monthDifference = today.getMonth() - birthDate.getMonth();
    
      // Adjust age if the birth month hasn't occurred yet this year
      if (monthDifference < 0 || (monthDifference === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
    
      return age;
    };
    
    const calculateAgeMonths = (dob) => {
      if (!dob) return 0;
      const birthDate = new Date(dob);
      const today = new Date();
      let months = (today.getFullYear() - birthDate.getFullYear()) * 12;
      months += today.getMonth() - birthDate.getMonth();
    
      // Adjust months if the birth date hasn't occurred yet this month
      if (today.getDate() < birthDate.getDate()) {
        months--;
      }
    
      return months;
    };
    
    const calculateAgeDays = (dob) => {
      if (!dob) return 0;
      const birthDate = new Date(dob);
      const today = new Date();
      const timeDiff = today - birthDate;
      const days = Math.floor(timeDiff / (1000 * 60 * 60 * 24));
      return days;
    };
    
    setFieldValue('PatientID', patientDetails.Patient_ID || '');
     setFieldValue('LedgertransactionID', patientDetails.LedgertransactionID || '');
     setFieldValue('LedgertransactionNo', patientDetails.LedgertransactionNo || '');
     setFieldValue('Mobile', patientDetails.mobile|| '');
     setFieldValue('Title', patientDetails.title || '');
     setFieldValue('PFirstName', patientDetails.PName || '');
    setFieldValue('Gender',{label:patientDetails.gender,value:patientDetails?.gender} || '');
     setFieldValue('years', calculateAgeYears(patientDetails.dob) || '');
    setFieldValue('months', calculateAgeMonths(patientDetails.dob) || '');
     setFieldValue('days', calculateAgeDays(patientDetails.dob) || '');
     setFieldValue('Doctor', patientDetails.Doctor || '');
     setFieldValue('Address', patientDetails.house_no || '');
     setFieldValue('Email', patientDetails.email || '');
     setFieldValue('Phone', patientDetails.ContactNo || '');
     setFieldValue('DateOfBirth', patientDetails.dob || '');
     setFieldValue('DOB', new Date(patientDetails.dob) || new Date());
     setFieldValue('Doctor_ID', patientDetails.Doctor_ID || '');
     setFieldValue('DoctorName', patientDetails.DoctorName || '');
     setFieldValue('Panel_ID', patientDetails.Panel_ID || '');
     setFieldValue('PanelName', patientDetails.PanelName || '');
     setFieldValue('Discount', patientDetails.Discount || 0);
     setFieldValue('PanelID', patientDetails.PanelID || '');
     setFieldValue('CentreId', patientDetails.CentreId || '');
     setFieldValue('mobedit',true)
     setFieldValue('ReferenceCodeOpd', patientDetails.ReferenceCodeOpd || '');
     setGetOldPatientData([])
      };
  const [documentIds, setDocumentIds] = useState([]);
  const handleAddDocumentIDs = (e) => {
    if (e.key === "Enter") {
      let docIDs = documentIds?.find(
        (item) =>
          item?.id === e.target.value ||
          item?.name?.value === values?.documentName?.value
      );
      let validDocLength = parseInt(
        values?.documentName?.value?.split("#")[1]
          ? values?.documentName?.value?.split("#")[1]
          : 0
      );
      if (!values?.documentName?.label) {
        notify("Please Select Document id", "error");
      } else if (!e.target.value) {
        notify("Document Can't Be Empty", "error");
      } else if (docIDs?.id) {
        notify("This Document  Has Already Added", "error");
      } else if (e.target.value?.length !== validDocLength) {
        notify(
          `${values?.documentName?.label} must be ${validDocLength} digit `,
          "error"
        );
      } else {
        setDocumentIds((val) => [
          ...val,
          { name: values?.documentName, id: e.target.value },
        ]);
        let ids = [...documentIds];
        ids.push({ name: values?.documentName, id: e.target.value });
        setValues((val) => ({
          ...val,
          ID_Proof_No: "",
          documentName: "",
          documentIds: ids,
        }));
      }
      handleKeyDown(e);
    }
  };
  const deleteDocument = (doc) => {
    const docDetail = documentIds?.filter((val) => val.id !== doc?.id);
    setValues((val) => ({ ...val, documentIds: docDetail }));
    setDocumentIds(docDetail);
  };

  const getAgeByDateOfBirth = (e, handleChange) => {
    const dob = moment(e.target.value);
    const now = moment();
    const years = now.diff(dob, "years");
    dob.add(years, "years");
    const months = now.diff(dob, "months");
    dob.add(months, "months");
    const days = now.diff(dob, "days");

    handleChange({ target: { name: "years", value: years } });
    handleChange({ target: { name: "months", value: months } });
    handleChange({ target: { name: "days", value: days } });

    handleChange(e);
  };

  const changedobbyage = (years, months, days) => {
    const dob = moment()
      .subtract(years, "years")
      .subtract(months, "months")
      .subtract(days, "days");
    
    handleChange({
      target: { name: "DOB", value: dob.format("YYYY-MM-DD") },
    });
  };
  useEffect(() => {
    if (values?.years || values?.months || values?.days) {
      // Only call the function if at least one value is not empty
      changedobbyage(values?.years, values?.months, values?.days);
    }
  }, [values?.years, values?.months, values?.days]);
  
  
  const handleTitleChange = (name, value) => {
    const selectedTitle = titleOptions.find(option => option.value === value.value);

    const selectedGender = genderOptions.find(gender => gender.value === selectedTitle?.gender);
    setFieldValue(name,value)
    setFieldValue('Gender',selectedTitle?.gender !== "UnKnown" ? selectedGender : null)
    
  };


 
  
  const handleOldPatientSearch = async (e) => {
    if ([13].includes(e.which)) {
      try {

        const form=new FormData();
        form.append('ID',localStorage.getItem('employeeId'))
        form.append('LoginName',localStorage.getItem('employeeName'))
        form.append('SessionCentreID','1')
        form.append('MobileNo',e?.target.name=='Mobile'?e?.target?.value:'')
        form.append('Patient_ID',e?.target.name=='UHID'?e?.target?.value:'')
        

        const dataResponse = await Oldpatientsearch(
          form
        ); 
      console.log(dataResponse)
      const modified=dataResponse?.data.data.map((item) => ({
        ...item, // Spread existing data
        modalPatientName: `${item.title} ${item.PName}`, // Combine title and PName
        modalAgeGender: `${item.age} / ${item.gender}`, // Combine age and gender
        modalAddress: `${item.house_no} ${item.Locality} ${item.City} ${item.State} ${item.Country}` // Combine address fields
      }));
      setGetOldPatientData(modified)
      } catch (error) {
        console.log(error);
      }
    }
  };
   useEffect(()=>{
     getCentresworkorder(setCenters,setFieldValue)
     getPaymentmode(setPaymentMethod)
   },[])
   useEffect(()=>{
    if(values?.CentreId.value)fetchPanelswithid(values?.CentreId.value,setPanels,setFieldValue)
    else fetchPanelswithid(values?.CentreId,setPanels,setFieldValue)
    
   },[values?.CentreId])
  
useEffect(() => {
    if (discounts.discamount) {
        const totalDiscount = parseFloat(discounts.discamount);
        const totalTests = testAddingTableState.length;
        const discountPerTest = totalDiscount / totalTests;

      setTestAddingTable((prevState) =>
            prevState.map((test) => ({
                ...test,
                Discount: discountPerTest.toFixed(2),
            }))
        );
    }
}, [discounts.discamount]);

useEffect(() => {
    if (discounts.discperc) {
        const discountPercentage = parseFloat(discounts.discperc);

        setTestAddingTable((prevState) =>
            prevState.map((test) => {
                const discount = (discountPercentage / 100) * parseFloat(test.Amount);
                return {
                    ...test,
                    Discount: discount.toFixed(2),
                };
            })
        );
    }
}, [discounts.discperc]);
  return (
    <>
      {addDoc && (
        <Modal
          modalWidth={"1000px"}
          visible={addDoc}
          setVisible={() => {
            setAdddoc(false);
          }}
          Header="Add Doctor"
        >
          <DoctoModal close={()=>{
            setAdddoc(false)
          }} setFormValue={setFieldValue}/>
        </Modal>
      )}
      <div className="card patient_registration">
        <div className="row pt-2 pl-2 pr-2">
        <div className="d-md-none">
          {/* <UploadImage /> */}

          <label
            style={{
              position: "absolute",
              zIndex: "1",
              top: "0px",
              right: "100px",
            }}
            id="document-s"
            onClick={() => setIsuploadDocOpen(true)}
          >
            <i class="fa fa-file" aria-hidden="true"></i>
          </label>
          <label
            style={{
              position: "absolute",
              zIndex: "1",
              top: "0px",
              right: "10px",
            }}
            onClick={() => setIsuploadOpen(true)}
          >
            Upload Image
          </label>
        </div>
         <div className="col-md-11 col-sm-12 ">
            <div className="row row-cols-lg-5 row-cols-md-2 row-cols-1">
            <ReactSelect
            placeholderName={t("Centre")}
            id={"Centre"}
            name={"CentreId"}
            searchable={true}
            respclass="col-5"
            value={values?.CentreId}
            dynamicOptions={Centres}
            handleChange={handleReactSelect}
            
          />
            <ReactSelect
            placeholderName={t("Client")}
            id={"Panel"}
            name={"PanelID"}
            searchable={true}
            respclass="col-5"
            value={values?.PanelID}
            dynamicOptions={Panels}
            handleChange={handleReactSelect}
          />
              <Input
                type="text"
                className="form-control "
                id="Barcode"
                name="Barcode"
                value={values?.Barcode}
                lable={t("FrontOffice.OPD.patientRegistration.Barcode")}
                placeholder=" "
                respclass="col-xl-2.5 col-md-3 col-sm-6 col-12"
                onChange={handleChange}
                disabled={values?.mobedit}
                // inputRef={inputRef}
              /> 
              <div className= "d-flex">
              <Input
                type="number"
                className="form-control w-100"
                id="Mobile"
                name="Mobile"
                value={values?.Mobile}
                onChange={(e) => {
                  inputBoxValidation(
                    MOBILE_NUMBER_VALIDATION_REGX,
                    e,
                    handleChange
                  );
                }}
                disabled={values?.mobedit}
                
                lable={t("FrontOffice.OPD.patientRegistration.Mobile_No")}
                placeholder=" "
                onKeyDown={(e) => {
                  handleOldPatientSearch(e);
                }}
                 respclass="col-11"
                maxLength={10}
                //tabIndex="1"
              /> 
             <button
        className="col-1 p-0 m-0 d-flex align-items-center justify-content-center"
        style={{
          height: "23.5px",
          border: "none",
          
          cursor: "default",
          color: "white",
          width: "40px", // Adjust size as needed
          fontSize: "14px",
        }}
        disabled
      >
        {10 - (values?.Mobile?.toString().length || 0)}
      </button>
              </div>
              
              
             

              <div className="col-xl-2.5 col-md-3 col-sm-6 col-12">
                <div className="row">
                  <ReactSelect
                    placeholderName={"Title"}
                    dynamicOptions={titleOptions}
                    // id={"Title"}
                    name="Title"
                    // inputClass="required-fields"
                    inputId="Title"
                    value={values?.Title}
                    handleChange={handleTitleChange}
                    searchable={true}
                    respclass="col-5 "
                    requiredClassName="required-fields"
                    // onKeyDown={Tabfunctionality}
                    //tabIndex="2"
                    isDisabled={values?.mobedit}
                  />

                  <Input
                    type="text"
                    className="form-control required-fields"
                    id="First"
                    name="PFirstName"
                    value={values?.PFirstName}
                    onChange={handleChange}
                    lable={t("FrontOffice.OPD.patientRegistration.First_Name")}
                    placeholder=" "
                    respclass="col-7"
                    disabled={values?.mobedit}

                    //tabIndex="3"
                  />
                </div>
              </div>

              <ReactSelect
                placeholderName={"Gender"}
                isDisabled={
                  values?.Gender?.value === "Male" || values?.Gender?.value === "Female"||values?.mobedit
                    ? true
                    : false
                }
                id="Gender"
               dynamicOptions={genderOptions}
                name="Gender"
                value={values?.Gender?.value}
                handleChange={handleReactSelect}
                
                respclass="col-5"
                requiredClassName={`required-fields ${values?.Gender === "Male" || values?.Gender === "Female" ? "disable-focus" : ""}`}
                
                //tabIndex="4"
              />

              <DatePicker
                className="custom-calendar"
                respclass="col-xl-2.5 col-md-3 col-sm-6 col-12"
                id="DOB"
                name="DOB"
                value={values?.DOB ? moment(values?.DOB).toDate() : ""}
                // handleChange={handleChange}
                handleChange={(e) => {
                  getAgeByDateOfBirth(e, handleChange);
                }}
                lable={"DOB"}
                placeholder={VITE_DATE_FORMAT}
                maxDate={new Date()}
                isDisabled ={values?.mobedit}
              />

              {localStorage.getItem('AgeType')==0 && <div className="col-xl-2.5 col-md-3 col-sm-6 col-12">
                <div className="row">
                  <Input
                    type="text"
                    className="form-control required-fields"
                    id="Age"
                    name="Age"
                    value={values?.Age}
                    onChange={(e) => {
                      ageValidation(
                        /^\d{0,2}(\.\d{0,2})?$/,
                        e,
                        handleChange,
                        values?.AgeType?.value
                          ? values?.AgeType?.value
                          : values?.AgeType
                      );
                    }}
                    lable={t("FrontOffice.OPD.patientRegistration.Age")}
                    placeholder=" "
                    respclass="col-5"
                    //tabIndex="5"
                  />

                  <ReactSelect
                    placeholderName={t(
                      "FrontOffice.OPD.patientRegistration.Type"
                    )}
                    id="Type"
                    name="AgeType"
                    value={values?.AgeType}
                    handleChange={handleReactSelect}
                    dynamicOptions={AGE_TYPE}
                    searchable={true}
                    respclass="col-7"
                    //tabIndex="-1"
                  />
                </div>
              </div>
              }
              
                {localStorage.getItem('AgeType')==1 && <div className="col-xl-2.5 col-md-3 col-sm-6 col-12">
                  <div className="row">
                    <Input
                      type="number"
                      className="form-control"
                      id="years"
                      name="years"
                      value={values?.years}
                      onChange={handleChange}
                      lable={"Years"}
                      placeholder=""
                      respclass="col-4"
                      
                    />
                    <Input
                      type="number"
                      className="form-control"
                      id="months"
                      name="months"
                      value={values?.months}
                      onChange={handleChange}
                      lable={"Months"}
                      placeholder=""
                      respclass="col-4"
                    />
                    <Input
                      type="number"
                      className="form-control"
                      id="days"
                      name="days"
                      value={values?.days}
                      onChange={handleChange}
                      lable={"Days"}
                      placeholder=""
                      respclass="col-4"
                    />
                  </div>
                </div>}
              
              {/* <AutoComplete
                    value={values?.DoctorName}
                    suggestions={doctorSuggestion}
                    className="col-xl-2.5 col-md-3 col-sm-6 col-12"
                    completeMethod={searchDoctors}
                    field="label" // Assuming 'label' is the field to display in suggestions
                    placeholder="Doctor"
                    id="Doctor"
                    name="DoctorName"
                    autoComplete="off"
                    onChange={(e) => {
                      setFieldValue("DoctorName", e.value);
                    }}
                    lable="Doctor"
                    onSelect={(e) => handleListSearch(e.value)}
                    inputRef={inputRef}
                    // Optional: Adds a dropdown button to see all suggestions
                  /> */}
              <div className="d-flex col-xl-2.5 col-md-3 col-sm-6 col-12">
                <AutoComplete
                  value={values?.DoctorName}
                  suggestions={doctorSuggestion}
                  className="w-100"
                  completeMethod={searchDoctors}
                  field="label" // Assuming 'label' is the field to display in suggestions
                  placeholder="Doctor"
                  id="Doctor"
                  name="DoctorName"
                  autoComplete="off"
                  onChange={(e) => {
                    setFieldValue("DoctorName", e.value);
                  }}
                  onSelect={(e) => handleListSearch(e.value)}
                  inputRef={inputRef}
                />
                <button style={{ height: "23.5px" }}>
                  <span
                    className="pi pi-plus"
                    onClick={() => setAdddoc(true)} // Function to add a doctor
                    aria-label="Add Doctor"
                    style={{
                      cursor: "pointer",
                      background: "none",
                      color: "white",
                      border: "none",
                      padding: "0",
                      boxShadow: "none",
                      width: "10px", // Adjust size as needed
                      // Adjust size as needed
                    }}
                  />
                </button>
              </div>

              <Input
                type="text"
                className="form-control "
                id="Local_Address"
                name="House_No"
                value={values?.House_No}
                onChange={handleChange}
                lable={t("Address")}
                placeholder=" "
                respclass="col-xl-2.5 col-md-3 col-sm-6 col-12"
                //tabIndex="-1"
                // onKeyDown={Tabfunctionality}
              />
              <Input
                type="text"
                className="form-control "
                id="Email"
                name="Email"
                value={values?.Email}
                onChange={handleChange}
                lable={t("Email")}
                placeholder=" "
                // required={true}
                respclass="col-xl-2.5 col-md-3 col-sm-6 col-12"
                // onKeyDown={Tabfunctionality}
                //tabIndex="-1"
                disabled={values?.mobedit}
              />

              <Input
                type="text"
                className="form-control"
                id="ID_Proof_No"
                name="ID_Proof_No"
                value={values?.ID_Proof_No}
                onChange={handleChange}
                lable={t("Clinical History")}
                placeholder=" "
                respclass="col-xl-2.5 col-md-3 col-sm-6 col-12"
                showTooltipCount={true}
                onKeyDown={handleAddDocumentIDs}
              />
              <Input
                type="text"
                className="form-control"
                id="ID_Proof_No"
                name="ID_Proof_No"
                value={values?.ID_Proof_No}
                onChange={handleChange}
                lable={t("SRF No.")}
                placeholder=" "
                respclass="col-xl-2.5 col-md-3 col-sm-6 col-12"
                showTooltipCount={true}
                onKeyDown={handleAddDocumentIDs}
              />
              <div className="col-xl-4 col-md-3 col-sm-4 col-12">
              <TestPayment
                testPaymentState={testPaymentState}
                setTestPaymentState={setTestPaymentState}
                payloadData={values}
                handleDoctorSelected={handleDoctorSelected}
                singlePatientData={singlePatientData}
                setTestAddingTable={setTestAddingTable}
                testAddingTableState={testAddingTableState}
               
                TestData={[]}
                
              />
              </div>
               
              <div className="col-1">
                <label className="switch">
                  <input type="checkbox" id="flexCheckDefault"  checked={values?.IsVip}
                  onChange={(e)=>{
                    console.log(e.target.value)
                    if(e.target.value=='on')setFieldValue('IsVip',1)
                    else  setFieldValue('IsVip',0) 
                    
                  }}/>
                  <span className="slider"></span>
                </label>
                <label className="form-check-label" htmlFor="flexCheckDefault">
                  VIP
                </label>
              </div>
             
            </div>
          </div>
          <div className="col-1 d-none d-md-block position-relative">
          <div
            style={{
              border: "1px solid grey",
              borderRadius: "5px",
              textAlign: "center",
              width: "67%",
              marginLeft: "10px",
            }}
            className="p-1"
          >
            <img
              height={50}
              // width={116}
              src={values?.profileImage}
              style={{ width: "100%" }}
               
              onClick={() => setIsuploadOpen(true)}
            />
          </div>
          {/* <div className="p-1 personalDetailUploadDocument">
            <Tooltip
              target={`#document-s`}
              position="top"
              content="Patient Document's"
              event="hover"
            />
            <button
              className="text-white rounded  position-absolute p-1"
              type="button"
              style={{
                width: "62%",
                fontSize: "11px",
                marginLeft: "5px",
                bottom: "5px",
              }}
              id="document-s"
              onClick={() => setIsuploadDocOpen(true)}
            >
              <i class="fa fa-file" aria-hidden="true"></i>
            </button>
           
          </div> */}
        </div>
        <div className="row">
  <div className="col-12 col-md-8"> {/* Use col-12 for mobile and col-md-7 for larger screens */}
    <TestAddingTable
      bodyData={testAddingTableState}
      setBodyData={setTestAddingTable}
      
      singlePatientData={singlePatientData}
      discounts={discounts}
      THEAD={THEAD}
      handleChange={handleChange}
    />
  </div>

  {testAddingTableState.length > 0 && (
    <div className="col-12 col-md-4"> {/* Use col-12 for mobile and col-md-5 for larger screens */}
      <PaymentGateway
        screenType={paymentControlModeState}
        setScreenType={setPaymentControlModeState}
        paymentMethod={paymentMethod}
        payloadData={values}
        setPaymentMethod={setPaymentMethod}
        discounts={discounts}
        setDiscounts={setDiscounts}
        testAddingTableState={testAddingTableState}
      />
    </div>
  )}

  {testAddingTableState.length > 0 && (
    <div className="col-1"
    style={{ textAlign: "end", float: "right" }}
    >
      <button className="button" type="submit">
        {t("Save")}
      </button>
    </div>
  )}
</div>

        </div>
      </div>

      {getOldPatientData?.length > 0 && (
        <div
          style={{
            position: "absolute",
            zIndex: 9,
            width: "80%",
            top: "63px",
          }}
        >
          <EasyUI
            dataBind={getOldPatientData}
            dataColoum={BIND_TABLE_OLDPATIENTSEARCH_REG}
            onClick={handleClickEasyUI}
          />
        </div>
      )}
      {isuploadDocOpen && (
        <AttachDoumentModal
          isuploadOpen={isuploadDocOpen}
          setIsuploadOpen={setIsuploadDocOpen}
          preview={preview}
          modelHeader={"Upload Patient Document"}
          handleImageChange={handleImageChange}
        />
      )}

      {isuploadOpen && (
        <UploadImageModal
          isuploadOpen={isuploadOpen}
          closeCameraStream={closeCameraStream}
          setIsuploadOpen={setIsuploadOpen}
          // preview={preview}
          modalData={{ preview: preview }}
          handleImageChange={handleImageChange}
          startCamera={startCamera}
          videoRef={videoRef}
          cameraStream={cameraStream}
          takePhoto={takePhoto}
          canvasRef={canvasRef}
          handleAPI={(data) => { setValues((val) => ({ ...val, profileImage: data?.preview })); setIsuploadOpen(false); closeCameraStream() }}
        />
      )}
    </>
  );
}

import React from 'react'

const Tpken = () => {
  return (
    <div>index</div>
  )
}

export default index
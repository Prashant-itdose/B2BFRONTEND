import React, { Fragment, Suspense, lazy, useEffect, useState } from "react";
import { Navigate, Route, Routes, useLocation } from "react-router-dom";
import Loading from "@app/components/loader/Loading";
import ErrorBoundary from "../layouts/error-Boundary";
import Layout from "@app/layouts";
import Authenticated from "@app/Guard/Authenticated.jsx";
import Guest from "@app/Guard/Guest.jsx";
import { useDispatch, useSelector } from "react-redux";

import { useLocalStorage } from "../utils/hooks/useLocalStorage";
import {
  GetBindMenu,
  GetBindResourceList,
  GetRoleListByEmployeeIDAndCentreID,
} from "../store/reducers/common/CommonExportFunction";
import DynamicLabSearch from "../pages/frontOffice/DynamicLabSearch/DynamicLabSearch";

function RenderRoute() {
  const { GetMenuList } = useSelector((state) => state?.CommonSlice);
  console.log(GetMenuList)
  // const localData = useLocalStorage("userData", "get");
  const location = useLocation();
  const dispatch = useDispatch();
  const [waitForRoute, setWaitForRoute] = useState(true);

  const fetchData = async () => {
    try {
      // await dispatch(
      //   GetRoleListByEmployeeIDAndCentreID({
      //     employeeID: localData?.employeeID,
      //     centreID: localData?.centreID,
      //   })
      // );

      // await dispatch(
      //   GetBindMenu({
      //     RoleID:9,
      //   })
      // );

      // await dispatch(GetBindResourceList());

      // setWaitForRoute(false);
    } catch (error) {
      console.error("Error fetching data:", error);
      setWaitForRoute(false);
    }
  };

  // useEffect(() => {
  //   if (1==1) {
  //     fetchData();
  //   } else {
  //     setWaitForRoute(false);
  //   }
  // }, [location]);

  // Define your routes after ensuring all necessary data is fetched
  const getAllUrls = [];
  GetMenuList?.forEach((menu) => {
    menu?.children.forEach((child) => {
      getAllUrls.push(child.url.toLowerCase());
    });
  });

  const bindroutes = allRoutes["roleRoutes"].reduce((acc, current) => {
    if (getAllUrls.includes(current?.path.toLowerCase())) {
      acc.push(current);
    }
    return acc;
  }, []);

  return (
    <ErrorBoundary>
      <Suspense fallback={<Loading />}>
        <Routes>
          <Route path="/" element={<Navigate to="/login" />} />
          
          {[...allRoutes["commonRoutes"], ...bindroutes]?.map(
            (route, index) => {
              const Component = route?.component;
              const Layout = route?.layout || Fragment;
              const Guard = route?.Guard || Fragment;
              return (
                <Route
                  path={route?.path}
                  exact={route?.exact}
                  key={index}
                  element={
                    <Guard>
                      <Layout>
                        <Component />
                      </Layout>
                    </Guard>
                  }
                />
              );
            }
          )}
          {/* <Route path="/DynamicLabSearch" element={<Guard>
                      <Layout>
                        <DynamicLabSearch />
                      </Layout>
                    </Guard>} /> */}
          {/* Catch-all route */}
          <Route path="*" element={<Navigate to="/dashboard" />} />
        </Routes>
      </Suspense>
    </ErrorBoundary>
  );
}

export default RenderRoute;

const allRoutes = {
  commonRoutes: [
    // {
    //   Guard: Authenticated,
    //   layout: Layout,
    //   path: "*",
    //   component: lazy(() => import("@app/pages/NotFound.jsx")),
    //   exact: true,
    // },
    {
      Guard: Authenticated,
      layout: Layout,
      path: "/dashboard",
      component: lazy(() => import("@app/pages/Dashboard.jsx")),
      exact: true,
    },
    {
      Guard: Authenticated,
      layout: Layout,
      path: "/QuotationMaster",
      component: lazy(() => import("@app/pages/QuotationMaster.jsx")),
      exact: true,
    },
    {
      Guard: Guest,
      path: "/login",
      component: lazy(() => import("../modules/login/Login")),
      exact: true,
    },
    {
      path: "/ForgetPassword",
      component: lazy(() => import("@app/modules/login/ForgetPassword.jsx")),
      exact: true,
    },
   
    {
    layout: Layout,
      path: "/ChangePassword",
      component: lazy(
        () => import("@app/pages/changePassword/ChangePassword.jsx")
      ),
      exact: true,
    },
    {Guard:Authenticated,
     layout:Layout,
      path:'/DynamicLabSearch',
      component:lazy(
       ()=> import("@app/pages/frontOffice/DynamicLabSearch/DynamicLabSearch.jsx")
      )
     },
     { Guard:Authenticated,
      layout: Layout,
      path: "/PatientLabSearch",
      component: lazy(
        () => import("@app/pages/frontOffice/PatientLabSearch/PatientLabSearch.jsx")
      ),
      exact: true,
    },
    { Guard:Authenticated,
      layout: Layout,
      path: "/LedgerReport",
      component: lazy(
        () => import("@app/pages/frontOffice/Re_Print/LedgerReport.jsx")
      ),
      exact: true,
    },
    { Guard:Authenticated,
      layout: Layout,
      path: "/LedgerInformation",
      component: lazy(
        () => import("@app/pages/frontOffice/Re_Print/LedgerTransaction.jsx")
      ),
      exact: true,
    },
    

    

  ],
  roleRoutes: [
    {
      // Guard: Authenticated,
      layout: Layout,
      path: "/ChangePassword",
      component: lazy(
        () => import("@app/pages/changePassword/ChangePassword.jsx")
      ),
      exact: true,
    },
    {
      layout: Layout,
      path: "/RegistrationEdit",
      component: lazy(
        () => import("@app/pages/RegistrationEdit/RegistrationEdit.jsx")
      ),
      exact: true,
    },
    { Guard:Authenticated,
      layout: Layout,
      path: "/PatientLabSearch",
      component: lazy(
        () => import("@app/pages/frontOffice/PatientLabSearch/PatientLabSearch.jsx")
      ),
      exact: true,
    },
    {
      layout: Layout,
      path: "/InvoiceReprint",
      component: lazy(
        () => import("@app/pages/frontOffice/Re_Print/InvoiceReprint.jsx")
      ),
      exact: true,
    },
    {
      layout: Layout,
      path: "/ReceiptSRSSettelment",
      component: lazy(
        () => import("@app/pages/frontOffice/Re_Print/ReceiptSRSSettelment.jsx")
      ),
      exact: true,
    },
    
    {
      Guard: Authenticated,
      layout: Layout,
      path: "/DirectPatientReg",
      component: lazy(
        () => import("@app/components/front-office/PersonalDetails.jsx")
      ),
      exact: true,
    },
   

    

    
    
   
      {
      Guard: Authenticated,
      layout: Layout,
      path: "/ReceiptReprint",
      component: lazy(
        () => import("@app/pages/frontOffice/Re_Print/ReceiptReprint.jsx")
      ),
      exact: true,
    },
    
   
    {
      Guard: Authenticated,
      layout: Layout,
      path: "/DownloadRateList",
      component: lazy(
        () => import("@app/pages/frontOffice/tools/DownloadRateList.jsx")
      ),
      exact: true,
    },

    // Reports Section Start
   
    {
      Guard: Authenticated,
      layout: Layout,
      path: "/collection-report",
      component: lazy(
        () => import("@app/pages/frontOffice/Reports/CollectionReport.jsx")
      ),
      exact: true,
    },
    
    
    
    
    
    
    
    
    
    
    
    
    
    // Reports Section End

    // Reports Section Start
  ],
};

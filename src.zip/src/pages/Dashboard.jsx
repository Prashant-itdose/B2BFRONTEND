// import { ContentHeader } from '@components';

import DashboardCard from "../components/UI/DashboardCard";

const Dashboard = () => {
  return (
    <div>
      {/* <ContentHeader title="Dashboard"  /> */}



      <section className="content p-2 my-1">
  <div className="container-fluid">
    <div className="row">
      <div className="col-lg-3 col-6">
        <div className="small-box bg-info" style={{ height: '75px' }}>
          <div className="inner" style={{ height: '100%' }}>
            <h4 style={{ fontSize: '1.5rem', color: '#fff' }}>Today</h4>
            <h3>Patient Count: 9</h3>
            <h3>Net Amount: 1500</h3>
          </div>
        </div>
      </div>
      <div className="col-lg-3 col-6">
        <div className="small-box bg-info" style={{ height: '75px' }}>
          <div className="inner" style={{ height: '100%' }}>
            <h4 style={{ fontSize: '1.5rem', color: '#fff' }}>Month</h4>
            <h3>Patient Count: 9</h3>
            <h3>Net Amount: 1500</h3>
          </div>
        </div>
      </div>
      <div className="col-lg-3 col-6">
        <div className="small-box bg-warning" style={{ height: '75px' }}>
          <div className="inner" style={{ height: '100%' }}>
            <h4 style={{ fontSize: '1.5rem', color: '#fff' }}>Expected</h4>
            <h3>Patient Count: 9</h3>
            <h3>Net Amount: 1500</h3>
          </div>
        </div>
      </div>
      <div className="col-lg-3 col-6">
        <div className="small-box bg-danger" style={{ height: '75px' }}>
          <div className="inner" style={{ height: '100%' }}>
            <h4 style={{ fontSize: '1.5rem', color: '#fff' }}>Outstanding</h4>
            <h3></h3>
            <h3>Amount: 1500</h3>
          </div>
        </div>
      </div>
      <div className="col-lg-3 col-6">
        <div className="small-box bg-danger" style={{ height: '75px' }}>
          <div className="inner" style={{ height: '100%' }}>
            <h4 style={{ fontSize: '1.5rem', color: '#fff' }}>ReceiptAmount</h4>
            <h3></h3>
            <h3>Amount: 1500</h3>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


    </div>
  );
};

export default Dashboard;

import React from 'react'

const Blank2 = () => {
  return (
    <div>Blank2</div>
  )
}

export default Blank2
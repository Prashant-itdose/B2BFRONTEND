import * as XLSX from "xlsx"; // Import the xlsx library
import * as FileSaver from "file-saver";

export const headers = {
  "Accept": "application/json",
  "Authorization": `Bearer ${localStorage.getItem('token')}`,
  "Content-Type": "multipart/form-data",
};

export const ExportToExcel = async (dataExcel) => {
  const filetype =
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";
  const fileExtension = ".xlsx";

  // Convert JSON data to a worksheet
  const ws = XLSX.utils.json_to_sheet(dataExcel);

  // Create a new workbook and append the worksheet
  const wb = { Sheets: { data: ws }, SheetNames: ["data"] };

  // Generate an Excel file in array format
  const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" });

  // Create a Blob from the Excel buffer
  const data = new Blob([excelBuffer], { type: filetype });

  // Save the Excel file using FileSaver
  FileSaver.saveAs(data, "excel" + fileExtension);
};
